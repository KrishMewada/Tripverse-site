
  # Travel Planning Website UI/UX

  This is a code bundle for Travel Planning Website UI/UX. The original project is available at https://www.figma.com/design/OsPcie19uJqv3WVxvanvpm/Travel-Planning-Website-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  